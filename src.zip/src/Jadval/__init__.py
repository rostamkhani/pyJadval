from AGGrid import (print2)

def main():
    """Entry point for the application script"""
    print("Call your main application code here")

__all__ = [
    "print2",
]