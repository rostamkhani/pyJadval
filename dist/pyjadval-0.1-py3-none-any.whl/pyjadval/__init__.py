import os
rootpath = os.path.abspath(os.path.dirname(__file__))

from pyjadval import AGGrid

def print_():
    print(rootpath)


def main():
    """Entry point for the application script"""
    print("Call your main application code here")
